// import React from "react";
// import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
// import "@fortawesome/fontawesome-free/css/all.css";
// import Layout from "./components/Layout/Layout";
// import MainMenu from "./components/Layout/Header/Mainmenu";
// import Slider from "./components/Slider";
// import Banner from "./components/Banner";
// import ProductSection from "./components/Product/ProductList";
// import FeatureSection from "./components/FeatureSection";
// import WishlistPage from "./components/Layout/Navigations/WishlistPage";
// import LoginPage from "./components/Layout/Navigations/LoginPage";
// import Signup from "./components/Pages/Signup";
// import CartPage from "./components/Pages/CartPage";

// function App() {
//   return (
//     <Router>
//       <Routes>
//         <Route
//           path="/"
//           element={
//             <Layout>
//               <MainMenu />
//               <Slider />
//               <Banner />
//               <ProductSection />
//               <FeatureSection />
//             </Layout>
//           }
//         />
//         <Route
//           path="/wishlist"
//           element={
//             <Layout>
//               <WishlistPage />
//             </Layout>
//           }
//         />
//         <Route path="/login" element={<LoginPage />} />
//         <Route
//           path="/cart"
//           element={
//             <Layout>
//               <CartPage />
//             </Layout>
//           }
//         />
//         <Route
//           path="/signup"
//           element={
//             <Layout>
//               <Signup />
//             </Layout>
//           }
//         />
//       </Routes>
//     </Router>
//   );
// }

// export default App;








import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Layout from "./components/Layout/Layout";
import MainMenu from "./components/Layout/Header/Mainmenu";
import Slider from "./components/Slider";
import Banner from "./components/Banner";
import ProductSection from "./components/Product/ProductList";
import FeatureSection from "./components/FeatureSection";
import WishlistPage from "./components/Layout/Navigations/WishlistPage";
import Login from "./components/Layout/Navigations/Login"; 
import Signup from "./components/Pages/Signup";
import CartPage from "./components/Pages/CartPage";
import Navbar from "./components/Layout/Navigations/Navbar";

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLogin = () => {
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
  };

  return (
    <Router>
      <Navbar isLoggedIn={isLoggedIn} onLogout={handleLogout} />
      <Routes>
        <Route
          path="/"
          element={
            <Layout>
              <MainMenu />
              <Slider />
              <Banner />
              <ProductSection />
              <FeatureSection />
            </Layout>
          }
        />
        <Route path="/wishlist" element={<WishlistPage />} />
        <Route path="/login" element={<Login onLogin={handleLogin} />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/cart" element={<CartPage />} />
      </Routes>
    </Router>
  );
}

const Navbar = ({ isLoggedIn, onLogout }) => {
  return (
    <nav>
      <ul>
        {isLoggedIn ? (
          <>
             
            <li>
              <Link to="/login">Login</Link>
            </li>
            <li>
              <button onClick={onLogout}>Logout</button>
            </li>
          </>
        ) : (
          <li>
           </li>
        )}
      </ul>
    </nav>
  );
};

export default App;
