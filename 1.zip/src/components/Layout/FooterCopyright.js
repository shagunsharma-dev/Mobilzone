import React from "react";

const FooterBottom = () => {
  return (
    <div className="width-100 footer2-bacbor">
      <p className="footer2-content">
        Copyright © 2023, dezven.com. All Rights Reserved
      </p>
    </div>
  );
};

export default FooterBottom;
