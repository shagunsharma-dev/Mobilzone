import React from "react";
import "../../../App.css";
import Breadcrumbs from "../../Layout/Navigations/Breadcrumbs";
import ProductSection from "../../Product/ProductList";
  
const WishlistPage = () => {
  const paths = [
    {
      name: "Home",
      url: "/",
      icon:"fa fa-home",
    },
{
  name: "Wishlist",
  url: "/wishlist",
  icon: "fa fa-heart",
},

    {
      name: " ",
      url: " ",
      icon: " ",
    },
  ];

  return (
    <div>
      <Breadcrumbs paths={paths} />
      <div>
        <ProductSection />
      </div>
    </div>
  );
};

export default WishlistPage;
